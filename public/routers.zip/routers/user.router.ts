import { Router, Request, Response } from 'express';
// import * as sql from 'mssql';
import { authProvider } from "../authprovider/authprovider";
const router = Router();

// "@odata.context": "https://graph.microsoft.com/v1.0/$metadata#directoryObjects",
// "value": [
//     {
//         "@odata.type": "#microsoft.graph.user",
//         "id": "fc6e2018-4d05-4f9e-90f8-a988aac8a329",
//         "businessPhones": [],
//         "displayName": "jakson",
//         "givenName": null,
//         "jobTitle": null,
//         "mail": null,
//         "mobilePhone": null,
//         "officeLocation": null,
//         "preferredLanguage": null,
//         "surname": null,
//         "userPrincipalName": "jaksonnepal@bagwanlinkaapoutlook.onmicrosoft.com"
//     },
// interface Users  {
//   value?: {
//     id: string
//     displayName: string
//     userPrincipalName: string
//   }[]
// }

interface Users{
  id:string;
  displayName:string;
  userPrincipalName:string;
}
interface UserIdsType{
  value:Users[]
}
router.post('/ids', async (req: Request, res: Response) => {
    const {userIDs} = req.body
    const token = await authProvider.getToken()
    console.log(token)
     const user = await authProvider.getUserName(token,userIDs)
      console.log("user", user)
 
    const result = user.value;
    const resultdata = result.map((user: Users) => {
        return {
            id: user.id,
            displayName: user.displayName,
            userPrincipalName: user.userPrincipalName
        }
    })
    
    res.status(200).json(resultdata)
});

router.get('/ids', async (req: Request, res: Response) => {
    const {userIDs} = req.body
    const token = await authProvider.getToken()
    console.log(token)
    const user = await authProvider.getUserName(token,userIDs)
    console.log("user", user)
    res.status(200).json(user)
});

export default router;
