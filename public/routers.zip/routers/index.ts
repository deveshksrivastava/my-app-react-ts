import { Router } from 'express';
import homeRouter from './home.routers';
import swaggerRouter from './swagger.routers';
import asrRouter from './asr.router';
import userRouter from './user.router';
import contentRouter from './content.router';
import swaggerJsdoc from 'swagger-jsdoc';

import swaggerUi from 'swagger-ui-express';
require('dotenv').config();

const router = Router();

const swaggerOptions: swaggerJsdoc.Options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Your API Name',
      version: '1.0.0',
      description: 'Your API Description',
    },
  },
  servers: [
    {
      url: 'http://localhost:5002/',
    },
  ],
  apis: ['**/*.ts'], // Replace with the path to your API routes
};

const specs = swaggerJsdoc(swaggerOptions);

router.use('/home', homeRouter);
router.use('/asr', asrRouter);
router.use('/users', userRouter);
router.use('/content', contentRouter);
router.use('/swager', swaggerRouter, swaggerUi.serve, swaggerUi.setup(specs));

export default router;
