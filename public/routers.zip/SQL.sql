--CREATE TABLE Category (
--  CategoryID INT IDENTITY(1, 1) PRIMARY KEY,
--  CategoryName VARCHAR(255) NOT NULL
--);


--INSERT INTO Category (CategoryName) VALUES
--  ('Physical Notification'),
--  ('Operation Metering'),
--  ('Performance Monitoring'),
--  ('Declare PN'),
--  ('Ramp Rate'),
--  ('Unavailability');


SELECT * FROM Category