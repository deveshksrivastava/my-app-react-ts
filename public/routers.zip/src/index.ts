import express, { Express, Request, Response, RequestHandler } from 'express';
import cors from 'cors';
import { DefaultAzureCredential } from '@azure/identity';
import { SecretClient } from '@azure/keyvault-secrets';
import mssql from 'mssql';
import router from '../routers';
import dotenv, { config } from 'dotenv';


const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

dotenv.config();

const port = process.env.PORT || 5001; // Use environment variable for port or default to 3000

// Example API endpoint (replace with your actual logic)
app.get('/host', (req: Request, res: Response) => {
  const data = { message: 'Hello from the API!' };
  res.json(data);
});

// console.log("access token", accesstoken)

app.use('/', router);

// Start the servers
app.listen(port, () => {
  // http://localhost:5001/api/data
  console.log(`Server listening on http://${process.env.HOST}:${port}`);
});
