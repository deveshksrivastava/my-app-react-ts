https://github.com/vinodnextcoder/nodejs-typescript-express-typeorm-mysql-boilerplate/


https://www.youtube.com/watch?v=YuhKhkQqtP8
